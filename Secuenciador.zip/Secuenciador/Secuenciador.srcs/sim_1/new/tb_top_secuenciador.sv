`timescale 1ns / 1ps


module tb_top_secuenciador();

    //señales de prueba
    logic clk;
    logic reset;
    logic din;
    logic mealy_out;
    logic moore_out;

    // Instanciación del módulo a probar (Device Under Test)
    top_secuenciador uut (
        .clk(clk),
        .reset(reset),
        .din(din),
        .mealy_out(mealy_out),
        .moore_out(moore_out)
    );

    // Generación del reloj (Periodo de 10ns -> 100MHz)
    always #5 clk = ~clk;

    // Bloque de estímulos
    initial begin
        // Valores iniciales
        clk = 0;
        reset = 1;
        din = 0;

        // Mantenemos el reset por unos ciclos
        #20 reset = 0;

        // Ingresamos datos sincronizados al flanco de bajada del reloj
        // para asegurar tiempos de setup/hold correctos en el flanco de subida.
        
        // Un poco de ruido inicial
        @(negedge clk) din = 1;
        @(negedge clk) din = 0;
        
        // --- INICIO DE LA SECUENCIA: 0 1 1 0 0 1 1 0 ---
        @(negedge clk) din = 0;
        @(negedge clk) din = 1;
        @(negedge clk) din = 1;
        @(negedge clk) din = 0;
        @(negedge clk) din = 0;
        @(negedge clk) din = 1;
        @(negedge clk) din = 1;
        @(negedge clk) din = 0; 
        // -----------------------------------------------
        // Nota: En este punto de la simulación, Mealy reaccionará de inmediato 
        // a este último '0'. Moore esperará al siguiente flanco de subida del reloj.

        // Añadimos un par de bits más para observar cómo se apagan las salidas
        @(negedge clk) din = 0;
        @(negedge clk) din = 1;
        @(negedge clk) din = 0;

        // Esperar un momento y terminar la simulación
        #40 $finish;
    end

endmodule