`timescale 1ns / 1ps

module top_secuenciador (
    input  logic clk,
    input  logic reset,
    input  logic din,
    output logic mealy_out,
    output logic moore_out
);

    // Instancia mily
    mealy_01100110 u_mealy (
        .clk(clk),
        .reset(reset),
        .input_data(din),
        .mealy_output(mealy_out)
    );

    // Instancia mur
    moore_01100110 u_moore (
        .clk(clk),
        .reset(reset),
        .input_data(din),
        .moore_output(moore_out)
    );

endmodule