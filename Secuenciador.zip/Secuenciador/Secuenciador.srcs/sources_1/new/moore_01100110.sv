`timescale 1ns / 1ps

module moore_01100110 (
    input  logic clk,
    input  logic reset,
    input  logic input_data,
    output logic moore_output
);

    typedef enum {q0, q1, q2, q3, q4, q5, q6, q7, q8} state_type;
    state_type state_reg, state_next;

    always_ff @(posedge clk, posedge reset) begin
        if (reset)
            state_reg <= q0;
        else
            state_reg <= state_next;
    end

    always_comb begin
        state_next = state_reg;
        case (state_reg)
            q0: if (input_data == 0) state_next = q1; else state_next = q0;
            q1: if (input_data == 1) state_next = q2; else state_next = q1;
            q2: if (input_data == 1) state_next = q3; else state_next = q1;
            q3: if (input_data == 0) state_next = q4; else state_next = q0;
            q4: if (input_data == 0) state_next = q5; else state_next = q1;
            q5: if (input_data == 1) state_next = q6; else state_next = q1;
            q6: if (input_data == 1) state_next = q7; else state_next = q1;
            q7: if (input_data == 0) state_next = q8; else state_next = q0;
            q8: if (input_data == 0) state_next = q1; else state_next = q2;
            default: state_next = q0;
        endcase
    end
    
    assign moore_output = (state_reg == q8) ? 1'b1 : 1'b0;

endmodule